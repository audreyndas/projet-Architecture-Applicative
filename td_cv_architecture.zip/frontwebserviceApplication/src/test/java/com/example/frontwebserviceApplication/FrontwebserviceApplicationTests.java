package com.example.frontwebserviceApplication;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FrontwebserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
